<!doctype html>
<html lang="fr">
   <head>
      <title>BJText</title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,700&amp;display=swap" rel="stylesheet">
      <link rel="stylesheet" href="/bjtext/asset/public/css/css.css" />
      <link rel="stylesheet"href="/bjtext/asset/public/css/bootstrap.min.css"/>
    <link rel="stylesheet"href="/bjtext/asset/public/css/bootstrap.css.map"/>
    <link rel="stylesheet"href="/bjtext/asset/public/css/bootstrap-grid.css"/>
    <link rel="stylesheet"href="/bjtext/asset/public/css/bootstrap-grid.css.map"/>
    <link rel="stylesheet"href="/bjtext/asset/public/css/bootstrap-reboot.css"/>
    <link rel="stylesheet"href="/bjtext/asset/public/css/bootstrap-reboot.css.map"/>
   </head>
   <body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
      <div class="site-wrap" id="home-section">
         <div class="site-mobile-menu site-navbar-target">
            <div class="site-mobile-menu-header">
               <div class="site-mobile-menu-close mt-3">
                  <span class="icon-close2 js-menu-toggle"></span>
               </div>
            </div>
            <div class="site-mobile-menu-body"></div>
         </div>
         <!--div class="top-bar">
            <div class="container">
               <div class="row">
                  <div class="col-12">
                     <a href="#" class=""><span class="mr-2  icon-envelope-open-o"></span> <span class="d-none d-md-inline-block"><span class="__cf_email__" data-cfemail="98f1f6fef7d8e1f7edeafcf7f5f9f1f6b6fbf7f5">[email&#160;protected]</span></span></a>
                     <span class="mx-md-2 d-inline-block"></span>
                     <a href="#" class=""><span class="mr-2  icon-phone"></span> <span class="d-none d-md-inline-block">1+ (234) 5678 9101</span></a>
                     <div class="float-right">
                        <a href="#" class=""><span class="mr-2  icon-twitter"></span> <span class="d-none d-md-inline-block">Twitter</span></a>
                        <span class="mx-md-2 d-inline-block"></span>
                        <a href="#" class=""><span class="mr-2  icon-facebook"></span> <span class="d-none d-md-inline-block">Facebook</span></a>
                     </div>
                  </div>
               </div>
            </div>
         </div-->
         <header class="site-navbar js-sticky-header site-navbar-target bg-success" role="banner" >
            <div class="container">
               <div class="row align-items-center position-relative">
                  <div class="site-logo">
                     <a href="index.php" class="text-warning text-decoration-none" style="text-decoration:none;"><span class="text-warning">BJText</a>
                  </div>
                  <div class="col-12">
                     <nav class="site-navigation text-right ml-auto" role="navigation">
                     
                        <ul class="site-menu main-menu js-clone-nav ml-auto d-none d-lg-block" id="nav">
                           
                        <li> <a href="../../controller/public/index.php #home-section" class="nav-link" >Acceuil</a> </li> 
                         
                           <li><a href="../../controller/public/index.php #blog-section" class="nav-link">Actualités</a></li>
                           <li class="toggleSubMenu"><a class="nav-link" style="cursor:pointer;">Bénin ▼</a>
                         <div id="culture">
                           <ul class="subMenu bg-success">   
                           
                                <li><a href="../../controller/public/index.php #services-section">♦Culture</a></li>
                                <li><a href="../../controller/public/index.php#why-us-section">♦Histoire</a></li> 
                           </ul>
                         </div>
                           </li>
                           <li>
                              <a href="../../controller/public/index.php #about-section" class="nav-link ">A propos</a>
                           </li>
                           
                          

                           <li><a href="../../controller/public/index.php #testimonials-section" class="nav-link">Avis des internautes</a></li>
                           <li><a href="../../controller/public/index.php #contact-section" class="nav-link">Contact</a></li>
                             
                           
                        </ul>
                     </nav>
                  </div>
                  <div class="toggle-button d-inline-block d-lg-none"><a href="#" class="site-menu-toggle py-5 js-menu-toggle text-black"><span class="icon-menu h3"></span></a></div>
               </div>
            </div>
         </header>
<?php
//var_dump($_GET['identifiant'],$_GET['description']);die();
$identifiant=htmlspecialchars($_GET['identifiant']);
$titre=htmlspecialchars($_GET['titre']);
$description=htmlspecialchars($_GET['description']);
$pdf=htmlspecialchars($_GET['pdf']);
if(isset($identifiant) AND isset($titre) AND isset($description) AND isset($pdf))
{
    if(empty($identifiant) OR empty($titre) OR empty($description) OR empty($pdf)){
        echo "veuillez remplir tous les champs";
        header('location: ../../controller/public/index.php');
    }else{
echo '<h1 class="bg-success text-center" style="color:white; margin-top:10px; width:40%; margin-left:30%; border-radius:20px;"> Texte: '.$identifiant.' '.$titre.'</h1>';
?>
<div class="container text-center" style="text-align:center; margin:auto;">
<div class="row">
    <div class="col-md-3">
       
    </div>
<div class="col-md-6 ">
        <?php
echo "<p>".$description."</p>"; ?>
</div>
    </div>
    <div class="col-md-3">  

    
</div>
</div>
    <?php
$lienLire='<div class="bg-success text-center" style="width:20%; margin:auto; border-radius:20px;"><a href="Lirepdf.php ? identifiant='.$identifiant.'&amp;'.'titre='.$titre.'&amp;'.'description='.$description.'&amp;'.'pdf='.$pdf.'" style="color:white; text-decoration:none; "><p> Lire le pdf sur ce texte</p></a></div>';
$lienTélécharger='<div class="bg-success text-center" style="width:20%; margin:auto; border-radius:20px;"><a href="Téléchargerpdf.php ? identifiant='.$identifiant.'&amp;'.'titre='.$titre.'&amp;'.'description='.$description.'&amp;'.'pdf='.$pdf.'" style="color:white; text-decoration:none;"><p> Télécharger pdf</p></a></div>';

}  
}
 echo $lienLire.'</br>';
 echo $lienTélécharger;
?>
<footer class="site-footer">
            <div class="container">
               <div class="row">
                  <div class="col-md-6">
                     <div class="row">
                        <!--div class="col-md-7">
                           <h2 class="footer-heading mb-4">About Us</h2>
                           <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum voluptate debitis voluptatum et dolorum.</p>
                        </div-->
                        <div class="col-md-4">
                           <h2 class="footer-heading mb-4">Fonctionnalités</h2>
                           <ul class="list-unstyled">
                              <li><a href="../../controller/public/index.php #home-section">Acceuil</a></li>
                              <li><a href="../../controller/public/index.php #blog-section">Actualités</a></li>
                              <li><a href="../../controller/public/index.php #services-section">Culture</a></li>
                              <li><a href="../../controller/public/index.php #why-us-section">Histoire</a></li>
                              <li><a href="../../controller/public/index.php#about-section">A propos</a></li>
                              <li><a href="../../controller/public/index.php#testimonials-section">Avis des internautes</a></li>
                              <li><a href="../../controller/public/index.php #contact-section">Contact</a></li>
                              
                           </ul>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-4 ml-auto">
                     <div class="mb-5">
                        <h2 class="footer-heading mb-4">S'abonner à Newsletter</h2>
                        <form action="newsletter.php" method="post" class="footer-suscribe-form">
                           <div class="input-group mb-3">
                              <input type="email" class="form-control border-secondary text-white bg-transparent" placeholder="Entrer votre Email" aria-label="Enter Email" aria-describedby="button-addon2" name="email" required >
                              <div class="input-group-append">
                                 <input type="submit" class="btn btn-primary text-white bg-success"  id="button-addon2" value="S'abonner" name="envoyer" required>
                              </div>
                           </div>
                     </div>
                     <h2 class="footer-heading mb-4">Follow Us</h2>
                     <a href="https://web.facebook.com/abuzweb/" class="smoothscroll pl-0 pr-3"><span class="icon-facebook"></span></a>
                     
                     </form>
                  </div>
               </div>
               <div class="row pt-5 mt-5 text-center">
                  <div class="col-md-12">
                     <div class="border-top pt-5">
                        <p>
                           Copyright &copy;<script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>document.write(new Date().getFullYear());</script> Tous droits réservéss | BJTEXT-<a href="https://abuzweb.com/" target="_blank">AbuzWeb</a>
                        </p>
                     </div>
                  </div>
               </div>
            </div>
         </footer>
</html>
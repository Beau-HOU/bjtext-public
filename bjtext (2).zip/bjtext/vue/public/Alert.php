<!doctype html>
<?php
  echo $alert;

?>
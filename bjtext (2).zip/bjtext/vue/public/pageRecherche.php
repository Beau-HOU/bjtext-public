<!doctype html>
<html lang="fr">
   <head>
      <title>BJText</title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,700&amp;display=swap" rel="stylesheet">
      <link rel="stylesheet" href="/bjtext/asset/public/css/css.css" />
      <link rel="stylesheet"href="/bjtext/asset/public/css/bootstrap.min.css"/>
    <link rel="stylesheet"href="/bjtext/asset/public/css/bootstrap.css.map"/>
    <link rel="stylesheet"href="/bjtext/asset/public/css/bootstrap-grid.css"/>
    <link rel="stylesheet"href="/bjtext/asset/public/css/bootstrap-grid.css.map"/>
    <link rel="stylesheet"href="/bjtext/asset/public/css/bootstrap-reboot.css"/>
    <link rel="stylesheet"href="/bjtext/asset/public/css/bootstrap-reboot.css.map"/>
   </head>
   <body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
      <div class="site-wrap" id="home-section">
         <div class="site-mobile-menu site-navbar-target">
            <div class="site-mobile-menu-header">
               <div class="site-mobile-menu-close mt-3">
                  <span class="icon-close2 js-menu-toggle"></span>
               </div>
            </div>
            <div class="site-mobile-menu-body"></div>
         </div>
         <!--div class="top-bar">
            <div class="container">
               <div class="row">
                  <div class="col-12">
                     <a href="#" class=""><span class="mr-2  icon-envelope-open-o"></span> <span class="d-none d-md-inline-block"><span class="__cf_email__" data-cfemail="98f1f6fef7d8e1f7edeafcf7f5f9f1f6b6fbf7f5">[email&#160;protected]</span></span></a>
                     <span class="mx-md-2 d-inline-block"></span>
                     <a href="#" class=""><span class="mr-2  icon-phone"></span> <span class="d-none d-md-inline-block">1+ (234) 5678 9101</span></a>
                     <div class="float-right">
                        <a href="#" class=""><span class="mr-2  icon-twitter"></span> <span class="d-none d-md-inline-block">Twitter</span></a>
                        <span class="mx-md-2 d-inline-block"></span>
                        <a href="#" class=""><span class="mr-2  icon-facebook"></span> <span class="d-none d-md-inline-block">Facebook</span></a>
                     </div>
                  </div>
               </div>
            </div>
         </div-->
         <header class="site-navbar js-sticky-header site-navbar-target bg-success" role="banner" >
            <div class="container">
               <div class="row align-items-center position-relative">
                  <div class="site-logo">
                     <a href="index.php" class="text-warning text-decoration-none" style="text-decoration:none;"><span class="text-warning">BJText</a>
                  </div>
                  <div class="col-12">
                     <nav class="site-navigation text-right ml-auto" role="navigation">
                     
                        <ul class="site-menu main-menu js-clone-nav ml-auto d-none d-lg-block" id="nav">
                           
                        <li> <a href="../../controller/public/index.php #home-section" class="nav-link" >Acceuil</a> </li> 
                         
                           <li><a href="../../controller/public/index.php #blog-section" class="nav-link">Actualités</a></li>
                           <li class="toggleSubMenu"><a class="nav-link" style="cursor:pointer;">Bénin ▼</a>
                         <div id="culture">
                           <ul class="subMenu bg-success">   
                           
                                <li><a href="../../controller/public/index.php #services-section">♦Culture</a></li>
                                <li><a href="../../controller/public/index.php#why-us-section">♦Histoire</a></li> 
                           </ul>
                         </div>
                           </li>
                           <li>
                              <a href="../../controller/public/index.php #about-section" class="nav-link ">A propos</a>
                           </li>
                           
                          

                           <li><a href="../../controller/public/index.php #testimonials-section" class="nav-link">Avis des internautes</a></li>
                           <li><a href="../../controller/public/index.php #contact-section" class="nav-link">Contact</a></li>
                             
                           
                        </ul>
                     </nav>
                  </div>
                  <div class="toggle-button d-inline-block d-lg-none"><a href="#" class="site-menu-toggle py-5 js-menu-toggle text-black"><span class="icon-menu h3"></span></a></div>
               </div>
            </div>
         </header>
         <div class="ftco-blocks-cover-1">
            <div class="ftco-cover-1 overlay" style="background-image: url('/bjtext/asset/public/images/bénin.jpg')">
               <div class="container">
                  <div class="row align-items-center justify-content-center text-center">
                     <div class="col-lg-6">
                        <h1 class="bg-success">Bénin, le miroir de l'Afrique</h1>
                        <p class="mb-5 bg-danger" style="color:white; font-weight:bold; font-size:16px;">Bienvenue sur ce site présentant quelques actualités sur le Bénin</p>
                        
                        <form action="traitementRecherche.php" method="post">
                        <p >   
<label for="Catégories" style="color:white; font-weight:bold; font-size:24px;">Choisisez une catégorie ?</label><br />
<select name="catégories" id="catégories" value=" <?php echo isset($_POST['catégories']) ? htmlspecialchars($_POST['catégories']):'' ;?>" required>

<option <?php if (isset($_POST['catégories']) && $_POST['catégories']=="Droit") echo "selected";?>>Droit</option>
<option <?php if (isset($_POST['catégories']) && $_POST['catégories']=="Fiscalité") echo "selected";?>>Fiscalité</option>
<option <?php if (isset($_POST['catégories']) && $_POST['catégories']=="Comptabilité") echo "selected";?>>Comptabilité</option>
<option <?php if (isset($_POST['catégories']) && $_POST['catégories']=="Autres décision et accords") echo "selected";?>>Autres décision et accords</option>


</select>
</p>
                           <div class="form-group d-flex">
                              
                              <input type="search" class="form-control"  placeholder="Rechercher ici un thème" name="search" value=" <?php echo isset($_POST['search']) ? htmlspecialchars($_POST['search']):'' ;?>" required>
                              

                              <input type="submit" class="btn btn-primary text-white px-4 bg-success" value="Rechercher" name="Submit">
                           </div>
                        </form>
                        <?php if(isset($submit)){
                           if(empty($search)){
                              echo '<p class="text-danger">'.$alert.'<p>';

                           }
                        }
                        ?>
                     </div>
                  </div>
               </div>
            </div>
            
            </div>
            <script src="/bjtext/asset/public/js/jquery-3.3.1.min.js"></script>
      <script src="/bjtext/asset/public/js/popper.min.js%2bbootstrap.min.js.pagespeed.jc.5jBm_S-jZO.js"></script><script>eval(mod_pagespeed_vlDYzScndM);</script>
      <script>eval(mod_pagespeed_YjJV9Zec0X);</script>
      <script src="/bjtext/asset/public/js/owl.carousel.min.js%2bjquery.sticky.js%2bjquery.waypoints.min.js%2bjquery.animateNumber.min.js.pagespeed.jc.8wzactwMFt.js"></script><script>eval(mod_pagespeed_5Itp8KFPL5);</script>
      <script>eval(mod_pagespeed_6XKpihyFUI);</script>
      <script>eval(mod_pagespeed_CWcqtDEx$W);</script>
      <script>eval(mod_pagespeed_EqsLWlwqpN);</script>
      <script src="/bjtext/asset/public/js/jquery.fancybox.min.js%2bjquery.easing.1.3.js%2baos.js.pagespeed.jc.WlBefT-D6w.js"></script><script>eval(mod_pagespeed_WRgVH4byVZ);</script>
      <script>eval(mod_pagespeed_8EGP7PJ6R0);</script>
      <script>eval(mod_pagespeed_8CEzBqzqOM);</script>
      <script src="/bjtext/asset/public/js/main.js"></script>
      <script>
         window.dataLayer = window.dataLayer || [];
         function gtag(){dataLayer.push(arguments);}
         gtag('js', new Date());
         
         gtag('config', 'UA-23581568-13');
         $(document).ready(function() {
	$("#nav > .toggleSubMenu").mouseover(function(e) {
		$(this).children("div").show();
	});
	$("#nav > .toggleSubMenu").mouseout(function(e) {
		$(this).children("div").hide();
	});
});
      </script>
      <!--script type="text/javascript" src="/bjtext/asset/public/js/jquery.js"></script>
      <script type="text/javascript">
      $(document).ready(function() {
	$("#nav > .toggleSubMenu").mouseover(function(e) {
		$(this).children("div").show();
	});
	$("#nav > .toggleSubMenu").mouseout(function(e) {
		$(this).children("div").hide();
	});
});
 </script-->
   </body>
</html>

   
<?php
   
   echo '<h2><div class="text-dark text-center" style="font-weight:bold;">'. $result.'</div></h2>';
   echo '<h4><div class="text-dark text-center" style="font-weight:bold;">'. $afficherCategories.'</div></h4>';
   $barre=barreDeRecherche($search,$categories);
   // Boucle pour pacourrir le tableau des résulltats
   $numero=1;
   
   $resultatFinal1="Aucun Résultat Trouvé";
   
 while($donnees=$barre->fetch()){
       
       $donnes=$donnees;
       
       if(!empty($donnees['texte_titre']) OR !empty($donnees['texte_mot_cles']) OR !empty($donnees['texte_description']))
       {
         
           $resultatFinal=array('id'=>$numero,'titre'=> $donnes['texte_titre'],'description'=>$donnes['texte_description'],'pdf'=>$donnes['texte_fichier_pdf']);
          
           $resultatFinal1='<div class="container"><div class="row"><div class="col-md-3"></div><div class="col-md-6"><ul class="list-group"><li class="list-group-item"><h5><a href="../../controller/public/traitementpdf.php ? identifiant='.$numero.'&amp;'.'titre='.$donnes["texte_titre"].'&amp;'.'description='.$donnes["texte_description"].'&amp;'.'pdf='.$donnes["texte_fichier_pdf"].'" style="text-decoration:none;"><p> Texte'.$resultatFinal['id']." : ".$resultatFinal['titre'].'</p></a></h5></li></ul></div><div class="col-md-3"></div></div></div>';
               echo $resultatFinal1;
   
       }
       $numero++;
   }
   if($resultatFinal1=="Aucun Résultat Trouvé"){
      echo $resultatFinal1;
   
   }
   
?>

<footer class="site-footer">
            <div class="container">
               <div class="row">
                  <div class="col-md-6">
                     <div class="row">
                        <!--div class="col-md-7">
                           <h2 class="footer-heading mb-4">About Us</h2>
                           <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum voluptate debitis voluptatum et dolorum.</p>
                        </div-->
                        <div class="col-md-4">
                           <h2 class="footer-heading mb-4">Fonctionnalités</h2>
                           <ul class="list-unstyled">
                              <li><a href="../../controller/public/index.php #home-section">Acceuil</a></li>
                              <li><a href="../../controller/public/index.php #blog-section">Actualités</a></li>
                              <li><a href="../../controller/public/index.php #services-section">Culture</a></li>
                              <li><a href="../../controller/public/index.php #why-us-section">Histoire</a></li>
                              <li><a href="../../controller/public/index.php#about-section">A propos</a></li>
                              <li><a href="../../controller/public/index.php#testimonials-section">Avis des internautes</a></li>
                              <li><a href="../../controller/public/index.php #contact-section">Contact</a></li>
                              
                           </ul>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-4 ml-auto">
                     <div class="mb-5">
                        <h2 class="footer-heading mb-4">S'abonner à Newsletter</h2>
                        <form action="newsletter.php" method="post" class="footer-suscribe-form">
                           <div class="input-group mb-3">
                              <input type="email" class="form-control border-secondary text-white bg-transparent" placeholder="Entrer votre Email" aria-label="Enter Email" aria-describedby="button-addon2" name="email" required >
                              <div class="input-group-append">
                                 <input type="submit" class="btn btn-primary text-white bg-success"  id="button-addon2" value="S'abonner" name="envoyer" required>
                              </div>
                           </div>
                     </div>
                     <h2 class="footer-heading mb-4">Follow Us</h2>
                     <a href="https://web.facebook.com/abuzweb/" class="smoothscroll pl-0 pr-3"><span class="icon-facebook"></span></a>
                     
                     </form>
                  </div>
               </div>
               <div class="row pt-5 mt-5 text-center">
                  <div class="col-md-12">
                     <div class="border-top pt-5">
                        <p>
                           Copyright &copy;<script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>document.write(new Date().getFullYear());</script> Tous droits réservéss | BJTEXT-<a href="https://abuzweb.com/" target="_blank">AbuzWeb</a>
                        </p>
                     </div>
                  </div>
               </div>
            </div>
         </footer>
<?php
include("Verifying_variable.php");
$identifiant=caractèreHtml($_GET['identifiant']);
$titre=caractèreHtml($_GET['titre']);
$description=caractèreHtml($_GET['description']);
$pdf=caractèreHtml($_GET['pdf']);
if(!isset($identifiant) AND !isset($titre) AND isset($description) AND !isset($pdf)){
    $alert="Veuillez renseigner toutes les valeurs";
    include("../../vue/public/Alert.php");
}else{
    // Type de contenu d'en-tête
    header("Content-type: application/pdf"); 
  header("Content-Length: " . filesize($pdf)); 
  // Envoyez le fichier au navigateur.
  readfile($pdf); 
}
?>
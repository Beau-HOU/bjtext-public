
    <?php

include("Verifying_variable.php");
$search=htmlspecialchars($_POST['search']);
$search=enleverCaractèreEspace($search);
$search=strip($search);
$categories=$_POST['catégories'];
$submit=$_POST['Submit'];

if(isset($submit)){
    if(empty($search) OR empty($categories)){
        $alert= "VEUILLEZ REMPLIR TOUS LES CHAMP";
        //include("../../vue/public/pageRecherche.php");
        include("../../vue/public/Alert.php");
        header('location:index.php');
    }else{
        require("../../model/requête_sql.php");
        $result= ' Résultats de la recherche ('.$search.')';
        $afficherCategories='Categories: '.$categories;

        
        
        include("../../vue/public/pageRecherche.php");
    }
    
}

?>

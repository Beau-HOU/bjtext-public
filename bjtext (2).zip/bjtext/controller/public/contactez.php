<?php 
   $nom=htmlspecialchars($_POST['nom']);
   $prenom= htmlspecialchars($_POST['prenom']);
   $email=htmlspecialchars($_POST['email']);
   $message=htmlspecialchars ($_POST['message']);
   $envoyer1= $_POST['envoyer'];
   if(isset($envoyer1))
{
        if(empty($nom) OR empty($prenom) OR empty($email) OR empty($message))
        {
        $alert="Veuillez remplir ce champ";
   }elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)){

    $alert="Veuillez founir une adresse email valide";

} else{
            require("../../model/requête_sql.php");
            contactez($nom,$prenom,$email,$message);
            $alert="Votre message a été bien envoyé";
            
   }
}
include("../../vue/public/contactezVue.php");

?>
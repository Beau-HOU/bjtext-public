<?php
function caractèreHtml($variable){
   $variables= htmlspecialchars($variable);
   return $variables;
}
function strip($variable){
    $variables= strip_tags($variable);
    return $variables;
 }
 function enleverCaractèreEspace($variable){
    $variables= trim($variable);
    return $variables;
 }

 function existerVariable($variable){
     if(empty($variable)){
        include("../../vue/public/Alert.php");
         
     }else{
         $variables=$variable;
     }
     return $variables;
 }
 ?>
 

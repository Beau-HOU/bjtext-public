<?php 
   
   $email=htmlspecialchars($_POST['email']);
   
   $envoyer2= $_POST['envoyer'];
   if(isset($envoyer2))
{
        if(empty($email))
        {
        $alert="Veuillez remplir ce champ";
   }elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)){

    $alert="Veuillez fournir un email valide";
} else{
            require("../../model/requête_sql.php");
            $alert=newsletter($email);
            
            
   }
}
include("../../vue/public/contactezVue.php");

?>
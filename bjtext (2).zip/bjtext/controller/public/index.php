<?php 
require("../../model/requête_sql.php");
    $resultat=selectActualites6();
         include("../../vue/public/home.php");

       //}
    //}

<?php
    include("../../vue/public/AffichageResultat.php");
   

    
?>
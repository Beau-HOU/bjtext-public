<?php
//include("Verifying_variable.php");
$identifiant=htmlspecialchars($_GET['identifiant']);
$titre=htmlspecialchars($_GET['titre']);
$description=htmlspecialchars($_GET['description']);
$pdf=htmlspecialchars($_GET['pdf']);
$name="abw-texte.pdf";
if(!isset($identifiant) AND !isset($titre) AND !isset($description) AND !isset($pdf)){
    $alert="VEUILLEZ REMPLIR TOUS LES CHAMP";
    include("../../vue/public/alert.php");
}else{
    header("Content-type: application/pdf"); 
    header('Content-Disposition: attachment; filename='.$name.'');
  header("Content-Length: " . filesize($pdf)); 
    
  // Envoyez le fichier au navigateur.
  readfile($pdf); 
}
?>


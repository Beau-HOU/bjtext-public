<?php 
   require("../../model/requête_sql.php");
   //$resultat=selectActualites();
   $id=htmlspecialchars($_GET['identifiant']);
   $titre=htmlspecialchars($_GET['titre']);
   $description=htmlspecialchars($_GET['description']);
   $contenu=htmlspecialchars($_GET['contenu']);
   $image=htmlspecialchars($_GET['image']);
   if(isset($id) AND isset($titre) AND isset($description) AND isset($contenu)AND isset($image) )

   {
       include("../../vue/public/voirActualitésvue.php");
   }


?>
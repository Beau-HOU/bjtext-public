<?php 
//Connexion à la base de données
include("connect_base_donnees.php");
//Fontion permettant d'insérer des textes
function insererTexte($titre_texte,$motCles_texte,$description_texte,$fichierPdf_texte){
	$requete=$bdd->prepare('INSERT INTO abw_texte(texte_titre, texte_mot_cles, 	texte_description,texte_fichier_pdf,texte_categories) VALUES(?,?,?,?)');
		$requete->execute(array($titre_texte,$motCles_texte,$description_texte,$fichierPdf_texte));
}
?>



<?php 
function barreDeRecherche($recherche, $categories){
    //Connexion à la  base données
    include("../../config.php");
    
    //selection des informations trouvés
    $resultat=$bdd->prepare('SELECT * FROM abw_texte WHERE (texte_titre Like ? OR texte_mot_cles Like ? OR texte_description Like ?) AND texte_categories =?');
		$resultat->execute(array("%".$recherche."%","%".$recherche."%","%".$recherche."%",$categories));
        return $resultat; 
}


function selectActualites6(){
    //Connexion à la  base données
    include("../../config.php");
    // Requête permettant de sélectionner les  six derniers actualités de la base de données 
    $resultat=$bdd->query('SELECT * FROM abw_news ORDER BY news_id DESC LIMIT  6');
    //$resultatTaille=$bdd->query('SELECT COUNT (*)FROM abw_news');
		
return $resultat;
}
function actualitesParPages($currentPage){
    //Connexion à la  base données
    include("../../config.php");
    $resultatTaille=$bdd->query("SELECT count(*) FROM abw_news");
      $donnees=$resultatTaille->fetchcolumn();
      //on défini le nombre d'article par page
      $nbrActualitesParPages=9;
      //On calcule le nombre Total de page
      $pagesTotal = ceil($donnees / $nbrActualitesParPages);

      // Calcul du 1er article de la page
      $premierPage = ($currentPage * $nbrActualitesParPages) - $nbrActualitesParPages;

      $sql = 'SELECT * FROM `abw_news` ORDER BY `news_id` DESC LIMIT :premier, :parpage;';

  // On prépare la requête
   $query = $bdd->prepare($sql);

   $query->bindValue(':premier', $premierPage, PDO::PARAM_INT);
    $query->bindValue(':parpage', $nbrActualitesParPages, PDO::PARAM_INT);

  // On exécute
$query->execute();

  // On récupère les valeurs dans un tableau associatif
$articles = $query->fetchAll(PDO::FETCH_ASSOC);
		return $articles;
}
function selectActualites(){
    //Connexion à la  base données
    include("../../config.php");
    // Requête permettant de sélectionner les actualités de la base de données 
    $resultat=$bdd->query('SELECT * FROM abw_news');
    
		
return $resultat;
}
function nombreDeLigne(){
    //Connexion à la  base données
    include("../../config.php");
    $resultatTaille=$bdd->query("SELECT count(*) FROM abw_news");
      $donnees=$resultatTaille->fetchcolumn();
      //on défini le nombre d'article par page
      $nbrActualitesParPages=9;
      //On calcule le nombre Total de page
      $pagesTotal = ceil($donnees / $nbrActualitesParPages);
      return $pagesTotal;
}
  
function contactez($nom, $prenom,$email, $message){
    //Connexion à la base de données
include("../../config.php");
//Fontion permettant d'insérer des textes
	$requete=$bdd->prepare('INSERT INTO abw_contact(contact_nom, contact_prenom, contact_email,contact_message) VALUES(?,?,?,?)');
		$requete->execute(array($nom,$prenom,$email,$message));
}

function newsletter($email){
    //Connexion à la base de données
include("../../config.php");
//Fontion permettant d'insérer des textes
$resultat=$bdd->prepare('SELECT * FROM abw_newsletter WHERE newsletter_email =?');
$resultat->execute(array($email));
$donnees=$resultat->fetch();
   if(is_null($donnees['newsletter_email'])){
    $requete=$bdd->prepare('INSERT INTO abw_newsletter(newsletter_email) VALUES(?)');
    $requete->execute(array($email));
    $message="Abonnement réeussi";
   }else{
       $message="Vous êtes déja un abonné";
   }
	
return $message;
}
?>

<?php 
//Connexion à la base de données
include("connect_base_donnees.php");
//Fontion permettant d'insérer des admins
function insererAdmin($adminEmail,$adminNom,$adminPassword){
	$requete=$bdd->prepare('INSERT INTO abw_admin(admin_email, admin_nom, 	admin_password) VALUES(?,?,?)');
		$requete->execute(array($adminEmail,$adminNom,$adminPassword));
}
?>
<?php 
//Connexion à la base de données
include("connect_base_donnees.php");
//Fontion permettant d'insérer des news
function insererNews($titre_news,$desccription_news,$contenuText_news,$image_news){
	$requete=$bdd->prepare('INSERT INTO abw_news(news_titre, news_description, news_contenutext,news_image) VALUES(?,?,?,?)');
		$requete->execute(array($titre_news,$desccription_news,$contenuText_news,$image_news));
}
?>
-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  jeu. 19 août 2021 à 16:11
-- Version du serveur :  5.7.26
-- Version de PHP :  7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `bjtext`
--

-- --------------------------------------------------------

--
-- Structure de la table `abw_admin`
--

DROP TABLE IF EXISTS `abw_admin`;
CREATE TABLE IF NOT EXISTS `abw_admin` (
  `admin_email` varchar(255) NOT NULL,
  `admin_nom` varchar(255) NOT NULL,
  `admin_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `abw_categories`
--

DROP TABLE IF EXISTS `abw_categories`;
CREATE TABLE IF NOT EXISTS `abw_categories` (
  `categories_id` int(255) NOT NULL AUTO_INCREMENT,
  `categories_libelles` varchar(255) NOT NULL,
  PRIMARY KEY (`categories_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `abw_contact`
--

DROP TABLE IF EXISTS `abw_contact`;
CREATE TABLE IF NOT EXISTS `abw_contact` (
  `contact_id` int(255) NOT NULL AUTO_INCREMENT,
  `contact_nom` varchar(20) NOT NULL,
  `contact_prenom` varchar(20) NOT NULL,
  `contact_email` varchar(100) NOT NULL,
  `contact_message` text NOT NULL,
  PRIMARY KEY (`contact_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `abw_contact`
--

INSERT INTO `abw_contact` (`contact_id`, `contact_nom`, `contact_prenom`, `contact_email`, `contact_message`) VALUES
(1, 'HOUNDO', 'Beaudelaire', 'beaudelairesylas@gmail.com', 'Bpnjour comment allez vous?'),
(2, 'HOUNDO', 'Beaudelaire', 'beaudelairesylas@gmail.com', 'Bpnjour comment allez vous?'),
(3, 'Viakin', 'Henoc', 'ssesybeaude@gmail.com', 'Salut'),
(4, 'Viakin', 'Henoc', 'ssesybeaude@gmail.com', 'Salut'),
(5, 'Viakin', 'Henoc', 'ssesybeaude@gmail.com', 'Salut'),
(6, 'HIDJO', 'Félicienne', 'ssesybeaude@gmail.com', 'Bonjour'),
(7, 'adjagoudoume', 'angelus', 'ssesybeaude@gmail.com', 'Bonjour'),
(8, 'HOUNDO', 'Laurette', 'ssesybeaude@gmail.com', 'Salut'),
(9, 'HOUNDO', 'eustache', 'huyy', 'iji'),
(10, 'MEVOGNON', 'Laurette', 'ssesybeaude@gmail.com', ',,,'),
(11, 'MEVOGNON', 'Laurette', 'ssesybeaude@gmail.com', ',,,'),
(12, 'l;lo;', 'l;lo;', 'beaudelairesylas@gmail.com', ';;;;'),
(13, 'l;lo;', 'l;lo;', 'beaudelairesylas@gmail.com', ';;;;'),
(14, 'HIDJO', 'angelus', 'ssesybeaude@gmail.com', ',,,'),
(15, 'MEVOGNON', 'Beaudelaire ', 'beaudelairesylas@gmail.com', ',,,');

-- --------------------------------------------------------

--
-- Structure de la table `abw_news`
--

DROP TABLE IF EXISTS `abw_news`;
CREATE TABLE IF NOT EXISTS `abw_news` (
  `news_id` int(255) NOT NULL AUTO_INCREMENT,
  `news_titre` varchar(70) NOT NULL,
  `news_description` varchar(150) NOT NULL,
  `news_contenutext` text NOT NULL,
  `news_image` varchar(255) NOT NULL,
  PRIMARY KEY (`news_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `abw_news`
--

INSERT INTO `abw_news` (`news_id`, `news_titre`, `news_description`, `news_contenutext`, `news_image`) VALUES
(1, 'Le président Talon est réeulu ', 'Au terme d\'une folle élection, son excellence monsieur Athanase Patrice Guillaume Talon est réélu comme Président de la République du Bénin', ' Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '../../asset/public/images_actualités/talon.jpg'),
(2, 'Le corana virus', 'L\'année 2020 a été marqué par l\'avènement du corana virus qui a tué des milliers de personne ,\r\nObligeant tout le monde à aller en confinement.', ' Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '../../asset/public/images_actualités/corona.png'),
(3, 'Le Trésor public béninois a 60 ans', '14 août 1961-14 août 2021 : Le Trésor public béninois à 60 ans. Pour le célébrer, les responsables de cette structure sous la coupole du Ministère', 'Le Trésor public est l’une des structures dont l’existence est intimement liée à celle de l’État. Partant, 60 ans de vie, c’est à la fois beaucoup et peu. Beaucoup, parce qu’à travers le temps, l’administration du Trésor a évolué et a dû faire face à de nombreux défis. Alors la durée de vie d’un État n’est qu’un détail insaisissable. Ainsi s’exprimait Hermann Orou TAKOU, Directeur de cabinet du Ministre d’État en charge de l’Économie et des Finances. ', '../../asset/public/images_actualités/argent.jpg'),
(4, 'Guide d\'orientation universitaire 2021-2022 - Licence\r\n', 'Une fois le baccalauréat obtenu, bacheliers et parents sontpréoccupés  par  la  poursuite  des  études  universitaires.', 'Pour les aider dans ce processus, à finaliser leurs choixd’orientation,  le  Ministère  de  l’Enseignement  Supérieur  etde la Recherche Scientifique met à leur disposition ce guide,compagnon  indispensable  pour  tous  les  nouveaux  bacheliers.', '../../asset/public/images_actualités/Etudiant.jpg'),
(5, 'Promotion de l\'Infrastructure Qualité ', 'Promouvoir la culture qualité au sein des entreprises et unités de production pour satisfaire aux exigences de la clientèle.', 'Dans la salle de conférence de la Direction départementale de l\'industrie et du Commerce Borgou-Alibori, les opérateurs économiques de la Cité des Kobourou se sont effectivement mobilisés pour venir se familiariser avec la notion d\'infrastructure qualité afin de la mettre au cœur de leur système de service et de production. ', '../../asset/public/images_actualités/parakou.jpg'),
(6, 'Grand Prix Littéraire du Bénin 2021 ', 'Le Grand Prix Littéraire du Bénin est une manifestation officielle du Ministère du Tourisme.', 'Il vise à : mettre en valeur la diversité de la création littéraire nationale ; faire découvrir et promouvoir les écrivains béninois et leurs œuvres ; encourager le professionnalisme chez les éditeurs nationaux ; déceler, stimuler et valoriser les jeunes talents littéraires ; favoriser le positionnement de notre pays sur la scène littéraire africaine et mondiale.', '../../asset/public/images_actualités/Littérature.jpg'),
(7, 'La Société Béninoise de Production d\'Électricité', 'Vous avez envie de relever de nouveaux défis dans le secteur de l’énergie !  Rejoignez la Société Béninoise de Production d’Electricité.', '1.Ingénieur des systèmes d’information : 1 poste 2.Gestionnaire des ressources humaines : 1 poste 3.Assistant en gestion (gestion des entreprises, gestion matérielle/logistique) : 1 poste 4.Ingénieur Mécanicien (pour les études des projets de production thermique à Moteurs/Turbine à gaz) : 2 postes 5.Ingénieur Génie Civil (études et suivi des projets de production d’énergie) : 1 poste 6.Ingénieur Réseau Télécom (Scada et DCS pour les études des projets de production d’énergie) : 1 poste', '../../asset/public/images_actualités/Electricite.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `abw_newsletter`
--

DROP TABLE IF EXISTS `abw_newsletter`;
CREATE TABLE IF NOT EXISTS `abw_newsletter` (
  `newsletter_id` int(255) NOT NULL AUTO_INCREMENT,
  `newsletter_email` varchar(200) NOT NULL,
  PRIMARY KEY (`newsletter_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `abw_newsletter`
--

INSERT INTO `abw_newsletter` (`newsletter_id`, `newsletter_email`) VALUES
(1, 'beaudelairesylas@gmail.com'),
(2, 'ssesybeaude@gmail.com'),
(3, 'bbb@gmail.vl'),
(4, 'ppp@pp.pipi'),
(5, 'Baba@pp.pp');

-- --------------------------------------------------------

--
-- Structure de la table `abw_texte`
--

DROP TABLE IF EXISTS `abw_texte`;
CREATE TABLE IF NOT EXISTS `abw_texte` (
  `texte_id` int(255) NOT NULL AUTO_INCREMENT,
  `texte_titre` varchar(255) NOT NULL,
  `texte_mot_cles` varchar(255) NOT NULL,
  `texte_description` text NOT NULL,
  `texte_fichier_pdf` varchar(255) NOT NULL,
  `texte_categories` varchar(255) NOT NULL,
  PRIMARY KEY (`texte_id`),
  KEY `FK_Produit` (`texte_categories`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `abw_texte`
--

INSERT INTO `abw_texte` (`texte_id`, `texte_titre`, `texte_mot_cles`, `texte_description`, `texte_fichier_pdf`, `texte_categories`) VALUES
(1, 'Education', 'eduquer', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '../../asset/public/fichier_pdf/tp5.pdf', 'Droit'),
(2, 'L\'argent en entreprise', 'entreprise', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '../../asset/public/fichier_pdf/tp7.pdf', 'Comptabilité'),
(3, 'Santé', '  eduquer', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '../../asset/public/fichier_pdf/tp6.pdf', 'Droit');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
